<section class="p-4 bg-white rounded-4 h-100 shadow w-50 mx-auto overflow-auto">
    <h2>Connecté</h2>
    <hr>
    <p>Bonjour, vous êtes connecté en tant que <?php echo $_SESSION['email']; ?>.</p>
    <p>Vous pouvez vous déconnecter en cliquant <a href="/disconnect">ici</a>.</p>
</section>